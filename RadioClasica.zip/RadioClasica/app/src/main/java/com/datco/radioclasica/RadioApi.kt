package com.datco.radioclasica

import org.json.JSONArray
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

object RadioApi {
    private val hosts = listOf(
        "https://de1.api.radio-browser.info",
        "https://at1.api.radio-browser.info",
        "https://nl1.api.radio-browser.info"
    )

    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")

    fun search(tag: String, countryCode: String, name: String): List<Station> {
        val q = StringBuilder("/json/stations/search?hidebroken=true&order=clickcount&reverse=true&limit=150")
        q.append("&tag=").append(enc(tag))
        if (countryCode.isNotEmpty()) q.append("&countrycode=").append(countryCode)
        if (name.isNotBlank()) q.append("&name=").append(enc(name.trim()))

        for (h in hosts) {
            try {
                val conn = URL(h + q).openConnection() as HttpURLConnection
                conn.connectTimeout = 8000
                conn.readTimeout = 12000
                conn.setRequestProperty("User-Agent", "DATCO-RadioClasica/1.0")
                if (conn.responseCode == 200) {
                    val txt = conn.inputStream.bufferedReader().use { it.readText() }
                    return parse(txt)
                }
            } catch (e: Exception) {
                // probar el siguiente servidor
            }
        }
        throw IOException("sin conexion")
    }

    private fun parse(txt: String): List<Station> {
        val arr = JSONArray(txt)
        val seen = HashSet<String>()
        val out = ArrayList<Station>()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            var url = o.optString("url_resolved")
            if (url.isEmpty()) url = o.optString("url")
            val name = o.optString("name").trim()
            if (url.isEmpty() || name.isEmpty() || !seen.add(url)) continue
            out.add(
                Station(
                    o.optString("stationuuid", url),
                    name,
                    url,
                    o.optString("country"),
                    o.optString("tags")
                )
            )
        }
        return out
    }
}
