package com.datco.radioclasica

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

object Prefs {
    private fun sp(c: Context) = c.getSharedPreferences("radio_clasica", Context.MODE_PRIVATE)

    fun favorites(c: Context): MutableList<Station> {
        val out = mutableListOf<Station>()
        try {
            val a = JSONArray(sp(c).getString("favs", "[]"))
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                out.add(
                    Station(
                        o.getString("id"), o.getString("name"), o.getString("url"),
                        o.optString("country"), o.optString("tags")
                    )
                )
            }
        } catch (e: Exception) {
        }
        return out
    }

    fun isFav(c: Context, url: String) = favorites(c).any { it.url == url }

    fun toggle(c: Context, s: Station) {
        val list = favorites(c)
        val existing = list.firstOrNull { it.url == s.url }
        if (existing != null) list.remove(existing) else list.add(0, s)
        val a = JSONArray()
        for (x in list) {
            a.put(
                JSONObject()
                    .put("id", x.id).put("name", x.name).put("url", x.url)
                    .put("country", x.country).put("tags", x.tags)
            )
        }
        sp(c).edit().putString("favs", a.toString()).apply()
    }
}
