package com.datco.radioclasica

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.util.AttributeSet
import android.view.View
import kotlin.random.Random

/** Fondo sobrio con pentagramas y notas musicales dibujadas, muy tenues. */
class NotesBackgroundView(context: Context, attrs: AttributeSet? = null) : View(context, attrs) {

    private val d = resources.displayMetrics.density
    private val notes = arrayOf("♪", "♫", "♩", "♬")

    private val notePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFFC9A24D.toInt()
        alpha = 20
    }
    private val linePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFFC9A24D.toInt()
        alpha = 16
        strokeWidth = 1f * d
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat()
        val h = height.toFloat()

        for (k in 0 until 3) {
            val base = h * (0.18f + 0.32f * k)
            for (i in 0 until 5) {
                val y = base + i * 13f * d
                canvas.drawLine(0f, y, w, y, linePaint)
            }
        }

        val rnd = Random(7)
        repeat(16) {
            val x = rnd.nextFloat() * w
            val y = rnd.nextFloat() * h
            notePaint.textSize = (36 + rnd.nextInt(80)) * d
            val angle = (rnd.nextInt(41) - 20).toFloat()
            canvas.save()
            canvas.rotate(angle, x, y)
            canvas.drawText(notes[rnd.nextInt(notes.size)], x, y, notePaint)
            canvas.restore()
        }
    }
}
