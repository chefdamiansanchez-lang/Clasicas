package com.datco.radioclasica

import android.Manifest
import android.content.ComponentName
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.EditText
import android.widget.ImageButton
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.common.util.concurrent.ListenableFuture

class MainActivity : AppCompatActivity() {

    private val genres = listOf(
        "Toda la clásica" to "classical",
        "Ópera" to "opera",
        "Barroco" to "baroque",
        "Piano" to "piano",
        "Música de cámara" to "chamber music",
        "Sinfónica" to "symphony"
    )

    private val countries = listOf(
        "" to "Todo el mundo", "AR" to "Argentina", "AU" to "Australia", "AT" to "Austria",
        "BE" to "Bélgica", "BR" to "Brasil", "CA" to "Canadá", "CL" to "Chile",
        "CN" to "China", "CO" to "Colombia", "KR" to "Corea del Sur", "HR" to "Croacia",
        "DK" to "Dinamarca", "ES" to "España", "US" to "Estados Unidos", "FI" to "Finlandia",
        "FR" to "Francia", "GR" to "Grecia", "NL" to "Países Bajos", "HU" to "Hungría",
        "IE" to "Irlanda", "IT" to "Italia", "JP" to "Japón", "MX" to "México",
        "NO" to "Noruega", "PL" to "Polonia", "PT" to "Portugal", "GB" to "Reino Unido",
        "CZ" to "Chequia", "RU" to "Rusia", "SE" to "Suecia", "CH" to "Suiza",
        "TR" to "Turquía", "UY" to "Uruguay", "DE" to "Alemania"
    )

    private lateinit var adapter: StationAdapter
    private lateinit var spGenre: Spinner
    private lateinit var spCountry: Spinner
    private lateinit var etSearch: EditText
    private lateinit var tvStatus: TextView
    private lateinit var tvNow: TextView
    private lateinit var tvNowSub: TextView
    private lateinit var btnPlay: ImageButton
    private lateinit var btnFavs: TextView

    private var controller: MediaController? = null
    private var controllerFuture: ListenableFuture<MediaController>? = null
    private var showFavs = false
    private var reqId = 0
    private var nowSubBase = ""
    private val handler = Handler(Looper.getMainLooper())
    private val searchRunnable = Runnable { load() }

    private val playerListener = object : Player.Listener {
        override fun onIsPlayingChanged(isPlaying: Boolean) {
            btnPlay.setImageResource(if (isPlaying) R.drawable.ic_pause else R.drawable.ic_play)
        }

        override fun onPlaybackStateChanged(playbackState: Int) {
            tvNowSub.text = if (playbackState == Player.STATE_BUFFERING) "Cargando…" else nowSubBase
        }

        override fun onPlayerError(error: PlaybackException) {
            Toast.makeText(
                this@MainActivity,
                "No se pudo reproducir esta emisora. Probá con otra.",
                Toast.LENGTH_SHORT
            ).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        spGenre = findViewById(R.id.spGenre)
        spCountry = findViewById(R.id.spCountry)
        etSearch = findViewById(R.id.etSearch)
        tvStatus = findViewById(R.id.tvStatus)
        tvNow = findViewById(R.id.tvNow)
        tvNowSub = findViewById(R.id.tvNowSub)
        btnPlay = findViewById(R.id.btnPlay)
        btnFavs = findViewById(R.id.btnFavs)

        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }

        adapter = StationAdapter(
            onClick = { play(it) },
            onFav = {
                Prefs.toggle(this, it)
                if (showFavs) load()
            },
            isFav = { Prefs.isFav(this, it.url) }
        )
        val rv = findViewById<RecyclerView>(R.id.rvStations)
        rv.layoutManager = LinearLayoutManager(this)
        rv.adapter = adapter

        spGenre.adapter = spinnerAdapter(genres.map { it.first })
        spCountry.adapter = spinnerAdapter(countries.map { it.second })

        val selListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                load()
            }

            override fun onNothingSelected(p: AdapterView<*>?) {}
        }
        spGenre.onItemSelectedListener = selListener
        spCountry.onItemSelectedListener = selListener

        etSearch.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {
                handler.removeCallbacks(searchRunnable)
                handler.postDelayed(searchRunnable, 600)
            }

            override fun afterTextChanged(s: Editable?) {}
        })
        etSearch.setOnEditorActionListener { v, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_SEARCH) {
                handler.removeCallbacks(searchRunnable)
                load()
                (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager)
                    .hideSoftInputFromWindow(v.windowToken, 0)
                true
            } else false
        }

        btnFavs.setOnClickListener {
            showFavs = !showFavs
            btnFavs.text = if (showFavs) "★ Favoritas" else "☆ Favoritas"
            btnFavs.setBackgroundResource(if (showFavs) R.drawable.bg_chip_active else R.drawable.bg_chip)
            load()
        }

        btnPlay.setOnClickListener {
            val c = controller ?: return@setOnClickListener
            if (c.isPlaying) c.pause() else if (c.mediaItemCount > 0) c.play()
        }

        val token = SessionToken(this, ComponentName(this, PlaybackService::class.java))
        val future = MediaController.Builder(this, token).buildAsync()
        controllerFuture = future
        future.addListener({
            try {
                val c = future.get()
                controller = c
                c.addListener(playerListener)
                if (c.mediaItemCount > 0) {
                    tvNow.text = c.mediaMetadata.title ?: ""
                    nowSubBase = c.mediaMetadata.artist?.toString() ?: ""
                    tvNowSub.text = nowSubBase
                    adapter.playingUrl = c.currentMediaItem?.localConfiguration?.uri?.toString()
                    btnPlay.setImageResource(if (c.isPlaying) R.drawable.ic_pause else R.drawable.ic_play)
                }
            } catch (e: Exception) {
            }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun spinnerAdapter(items: List<String>): ArrayAdapter<String> {
        val a = ArrayAdapter(this, R.layout.spinner_item, items)
        a.setDropDownViewResource(R.layout.spinner_dropdown)
        return a
    }

    private fun load() {
        val q = etSearch.text.toString()
        val myReq = ++reqId

        if (showFavs) {
            val list = Prefs.favorites(this).filter { q.isBlank() || it.name.contains(q, true) }
            adapter.submit(list)
            tvStatus.text = "Todavía no tenés emisoras favoritas.\nTocá la ☆ de una emisora para guardarla."
            tvStatus.visibility = if (list.isEmpty()) View.VISIBLE else View.GONE
            return
        }

        val tag = genres[spGenre.selectedItemPosition].second
        val cc = countries[spCountry.selectedItemPosition].first
        tvStatus.text = "Buscando emisoras…"
        tvStatus.visibility = View.VISIBLE

        Thread {
            val result = try {
                RadioApi.search(tag, cc, q)
            } catch (e: Exception) {
                null
            }
            runOnUiThread {
                if (myReq == reqId) {
                    if (result == null) {
                        adapter.submit(emptyList())
                        tvStatus.text = "No se pudo conectar.\nRevisá tu conexión a internet."
                        tvStatus.visibility = View.VISIBLE
                    } else {
                        adapter.submit(result)
                        tvStatus.text = "No hay emisoras con ese filtro."
                        tvStatus.visibility = if (result.isEmpty()) View.VISIBLE else View.GONE
                    }
                }
            }
        }.start()
    }

    private fun play(s: Station) {
        val c = controller
        if (c == null) {
            Toast.makeText(this, "Conectando con el reproductor…", Toast.LENGTH_SHORT).show()
            return
        }
        val md = MediaMetadata.Builder()
            .setTitle(s.name)
            .setArtist(s.country.ifEmpty { "Radio" })
            .build()
        val item = MediaItem.Builder()
            .setMediaId(s.id)
            .setUri(s.url)
            .setMediaMetadata(md)
            .setRequestMetadata(MediaItem.RequestMetadata.Builder().setMediaUri(Uri.parse(s.url)).build())
            .build()
        c.setMediaItem(item)
        c.prepare()
        c.play()

        tvNow.text = s.name
        nowSubBase = s.country.ifEmpty { "Radio" }
        tvNowSub.text = "Cargando…"
        adapter.playingUrl = s.url
    }

    override fun onDestroy() {
        handler.removeCallbacks(searchRunnable)
        controller?.removeListener(playerListener)
        controllerFuture?.let { MediaController.releaseFuture(it) }
        super.onDestroy()
    }
}
