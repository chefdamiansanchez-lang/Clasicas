package com.datco.radioclasica

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView

class StationAdapter(
    private val onClick: (Station) -> Unit,
    private val onFav: (Station) -> Unit,
    private val isFav: (Station) -> Boolean
) : RecyclerView.Adapter<StationAdapter.VH>() {

    private var items: List<Station> = emptyList()

    var playingUrl: String? = null
        set(value) {
            field = value
            notifyDataSetChanged()
        }

    fun submit(list: List<Station>) {
        items = list
        notifyDataSetChanged()
    }

    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val name: TextView = v.findViewById(R.id.tvName)
        val sub: TextView = v.findViewById(R.id.tvSub)
        val star: TextView = v.findViewById(R.id.tvStar)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH =
        VH(LayoutInflater.from(parent.context).inflate(R.layout.item_station, parent, false))

    override fun getItemCount() = items.size

    override fun onBindViewHolder(h: VH, position: Int) {
        val s = items[position]
        val ctx = h.itemView.context
        h.name.text = s.name
        val tags = s.tags.split(",").map { it.trim() }.filter { it.isNotEmpty() }.take(2).joinToString(", ")
        h.sub.text = listOf(s.country, tags).filter { it.isNotBlank() }.joinToString(" · ")
        val playing = s.url == playingUrl
        h.name.setTextColor(ContextCompat.getColor(ctx, if (playing) R.color.gold else R.color.cream))
        h.star.text = if (isFav(s)) "★" else "☆"
        h.itemView.setOnClickListener { onClick(s) }
        h.star.setOnClickListener {
            onFav(s)
            val pos = h.bindingAdapterPosition
            if (pos != RecyclerView.NO_POSITION) notifyItemChanged(pos)
        }
    }
}
