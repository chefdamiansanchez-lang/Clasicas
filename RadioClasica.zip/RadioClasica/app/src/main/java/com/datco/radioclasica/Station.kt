package com.datco.radioclasica

data class Station(
    val id: String,
    val name: String,
    val url: String,
    val country: String,
    val tags: String
)
